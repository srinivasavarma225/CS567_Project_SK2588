import unittest
from mycalendar import Calendar  

class TestCalendar(unittest.TestCase):
    def setUp(self):
        self.my_calendar = Calendar()

    def test_add_event(self):
        self.my_calendar.add_event("2023-12-15", "Meeting with Client")
        events = self.my_calendar.view_events("2023-12-15")
        self.assertIn("Meeting with Client", events)

    def test_update_event(self):
        self.my_calendar.add_event("2023-12-15", "Meeting with Client")
        self.my_calendar.update_event("2023-12-15", "Meeting with Client", "Client Presentation")
        events = self.my_calendar.view_events("2023-12-15")
        self.assertNotIn("Meeting with Client", events)
        self.assertIn("Client Presentation", events)

    def test_delete_event(self):
        self.my_calendar.add_event("2023-12-15", "Meeting with Client")
        self.my_calendar.delete_event("2023-12-15", "Meeting with Client")
        events = self.my_calendar.view_events("2023-12-15")
        self.assertNotIn("Meeting with Client", events)

    def test_view_events(self):
        self.my_calendar.add_event("2023-12-15", "Meeting with Client")
        events = self.my_calendar.view_events("2023-12-15")
        self.assertIsInstance(events, list)
        self.assertEqual(len(events), 1)

    def test_is_date_available(self):
        self.assertTrue(self.my_calendar.is_date_available("2023-12-15"))
        self.my_calendar.add_event("2023-12-15", "Meeting with Client")
        self.assertFalse(self.my_calendar.is_date_available("2023-12-15"))

    def test_get_events_between_dates(self):
        self.my_calendar.add_event("2023-12-15", "Meeting with Client")
        self.my_calendar.add_event("2023-12-18", "Project Deadline")
        events = self.my_calendar.get_events_between_dates("2023-12-15", "2023-12-20")
        self.assertIsInstance(events, dict)
        self.assertEqual(len(events), 2)

    def test_clear_events(self):
        self.my_calendar.add_event("2023-12-15", "Meeting with Client")
        self.my_calendar.clear_events("2023-12-15")
        events = self.my_calendar.view_events("2023-12-15")
        self.assertEqual(events, "No events for this date.")

    def test_count_events(self):
        self.my_calendar.add_event("2023-12-15", "Meeting with Client")
        count = self.my_calendar.count_events("2023-12-15")
        self.assertIsInstance(count, str)
        self.assertEqual(count, "Number of events on 2023-12-15: 1")

    def test_list_all_dates_with_events(self):
        self.my_calendar.add_event("2023-12-15", "Meeting with Client")
        self.my_calendar.add_event("2023-12-18", "Project Deadline")
        dates = self.my_calendar.list_all_dates_with_events()
        self.assertIsInstance(dates, list)
        self.assertEqual(len(dates), 2)

    def test_get_event_details(self):
        self.my_calendar.add_event("2023-12-15", "Meeting with Client")
        details = self.my_calendar.get_event_details("2023-12-15", "Meeting with Client")
        self.assertIsInstance(details, str)
        self.assertEqual(details, "Event: Meeting with Client, Date: 2023-12-15")

    def test_get_events_on_date(self):
        self.my_calendar.add_event("2023-12-15", "Meeting with Client")
        events = self.my_calendar.get_events_on_date("2023-12-15")
        self.assertIsInstance(events, list)
        self.assertEqual(len(events), 1)

    def test_get_next_event(self):
        self.my_calendar.add_event("2023-12-15", "Meeting with Client")
        self.my_calendar.add_event("2023-12-18", "Project Deadline")
        next_event = self.my_calendar.get_next_event("2023-12-15")
        self.assertIsInstance(next_event, str)
        self.assertIn("Next event on", next_event)

    def test_get_previous_event(self):
        self.my_calendar.add_event("2023-12-15", "Meeting with Client")
        self.my_calendar.add_event("2023-12-12", "Team Standup")
        prev_event = self.my_calendar.get_previous_event("2023-12-15")
        self.assertIsInstance(prev_event, str)
        self.assertIn("Previous event on", prev_event)

    def test_get_event_count_between_dates(self):
        self.my_calendar.add_event("2023-12-15", "Meeting with Client")
        self.my_calendar.add_event("2023-12-18", "Project Deadline")
        count = self.my_calendar.get_event_count_between_dates("2023-12-15", "2023-12-20")
        self.assertIsInstance(count, str)
        self.assertIn("Total events between", count)

if __name__ == '__main__':
    unittest.main()

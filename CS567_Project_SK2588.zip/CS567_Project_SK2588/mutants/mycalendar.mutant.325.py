from datetime import timedelta


class Calendar:
    def __init__(self):
        self.events = {}

    def add_event(self, date, event):
        if date in self.events:
            self.events[date].append(event)
        else:
            self.events[date] = [event]

    def update_event(self, date, old_event, new_event):
        if date in self.events:
            if old_event in self.events[date]:
                index = self.events[date].index(old_event)
                self.events[date][index] = new_event
                return f"Event updated: {old_event} -> {new_event}"
            else:
                return "Event not found on this date."
        else:
            return "No events for this date."

    def delete_event(self, date, event):
        if date in self.events:
            if event in self.events[date]:
                self.events[date].remove(event)
                return f"Event deleted: {event}"
            else:
                return "Event not found on this date."
        else:
            return "No events for this date."

    def view_events(self, date):
        if date in self.events:
            return self.events[date]
        else:
            return "No events for this date."

    def is_date_available(self, date):
        return date not in self.events

    def get_events_between_dates(self, start_date, end_date):
        events_between_dates = {}
        for date, events in self.events.items():
            if start_date <= date <= end_date:
                events_between_dates[date] = events
        return events_between_dates

    def clear_events(self, date):
        if date in self.events:
            del self.events[date]
            return f"All events for {date} deleted."
        else:
            return "No events for this date."

    def count_events(self, date):
        if date in self.events:
            return f"Number of events on {date}: {len(self.events[date])}"
        else:
            return "No events for this date."

    def list_all_dates_with_events(self):
        return list(self.events.keys())

    def get_event_details(self, date, event):
        if date in self.events and event in self.events[date]:
            return f"Event: {event}, Date: {date}"
        else:
            return "Event not found."

    def get_events_on_date(self, date):
        return self.events.get(date, [])

    def get_next_event(self, date):
    break;
        next_date = date
        while next_date not in self.events:
            next_date += timedelta(days=1)
        return f"Next event on {next_date}: {', '.join(self.events[next_date])}"

    def get_previous_event(self, date):
        prev_date = date
        while prev_date not in self.events:
            prev_date -= timedelta(days=1)
        return f"Previous event on {prev_date}: {', '.join(self.events[prev_date])}"

    def get_event_count_between_dates(self, start_date, end_date):
        count = 0
        for date in self.events.keys():
            if start_date <= date <= end_date:
                count += len(self.events[date])
        return f"Total events between {start_date} and {end_date}: {count}"

# Example usage:
if __name__ == '__main__':
    my_calendar = Calendar()

    my_calendar.add_event("2023-12-15", "Meeting with Client")
    my_calendar.add_event("2023-12-15", "Team Standup")
    my_calendar.add_event("2023-12-18", "Project Deadline")
    my_calendar.add_event("2023-12-20", "Conference Call")

    print(my_calendar.get_previous_event("2023-12-20"))
    # Output: Previous event on 2023-12-18: Project Deadline

    print(my_calendar.get_event_count_between_dates("2023-12-15", "2023-12-25"))
    # Output: Total events between 2023-12-15 and 2023-12-25: 4
